﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pung
{
    class Program
    {


        private static bool[,] usedGridPositions;
        public const int timeScale = 100;
        public struct Vector2
        {
            public int x;
            public int y;

            public Vector2(int x, int y)
            {
                this.x = x;
                this.y = y;
            }

        }

        public static int playerLenth = 6;

        public class Player
        {
            public Vector2 Position;
            public int Score = 0;

            public Dictionary<ConsoleKey, Vector2> InputDirections;
        }


        private static Player playerOne = new Player()
        {

            InputDirections = new Dictionary<ConsoleKey, Vector2>()
            {
                    {
                        ConsoleKey.W, new Vector2(0, -1)
                    },
                    {
                        ConsoleKey.S, new Vector2(0, 1)
                    },
            }
        };

        private static Player playerTwo = new Player()
        {

            InputDirections = new Dictionary<ConsoleKey, Vector2>()
            {
                    {
                        ConsoleKey.UpArrow, new Vector2(0, -1)
                    },
                    {
                        ConsoleKey.DownArrow, new Vector2(0, 1)
                    },
            }
        };

        private static Player Ball = new Player()
        {

            InputDirections = new Dictionary<ConsoleKey, Vector2>()
            {
                    {
                        ConsoleKey.UpArrow, new Vector2(0, -1)
                    },
                    {
                        ConsoleKey.DownArrow, new Vector2(0, 1)
                    },
            }
        };
        private static void DrawPlayer(int positionX, int PositionY, char PlayerSymbol, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.SetCursorPosition(positionX, PositionY);
            Console.WriteLine(PlayerSymbol);

        }

        static void Main(string[] args)
        {
            #region Draw the start screen
            int times = 0;
            var title = "Pung";
            Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(title);

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Player One's Controls: \n\nW - Up\nS - Down");

            var playerTwoControlTitle = "Player Two's Controls:";
            var playerTwoControlTitleCursorLeftPosition = Console.BufferWidth - playerTwoControlTitle.Length;
            Console.CursorTop = 1;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.CursorLeft = playerTwoControlTitleCursorLeftPosition;
            Console.WriteLine(playerTwoControlTitle);
            Console.CursorLeft = playerTwoControlTitleCursorLeftPosition;
            Console.WriteLine("UpArrow - Up");
            Console.CursorLeft = playerTwoControlTitleCursorLeftPosition;
            Console.WriteLine("DownArrow - Down");

            Console.ReadKey();
            #endregion

            int moveNumY = 1;
            int moveNumX = 1;
            int points1 = 0;
            int points2 = 0;
            while (true)
            {
                Console.Clear();
                Console.BufferHeight = 30;
                Console.WindowHeight = 30;
                Console.WindowWidth = 80;
                Console.BufferWidth = 80;

                usedGridPositions = new bool[Console.WindowWidth + 1, Console.WindowHeight + 1];

                playerOne.Position.x = 1;
                playerOne.Position.y = Console.WindowHeight / 2;

                playerTwo.Position.x = Console.WindowWidth - 2;
                playerTwo.Position.y = Console.WindowHeight / 2;

                Ball.Position.x = Console.WindowWidth / 2;
                Ball.Position.y = Console.WindowHeight / 2;



                while (true)
                {
                    Console.CursorVisible = false;
                    Console.Clear();

                    DrawPlayer(Ball.Position.x, Ball.Position.y, 'O', ConsoleColor.Red);
                    usedGridPositions[playerOne.Position.x, playerOne.Position.y] = true;
                    usedGridPositions[playerTwo.Position.x, playerTwo.Position.y] = true;

                    DrawPlayer(playerOne.Position.x, playerOne.Position.y + 2, '|', ConsoleColor.Yellow);
                    DrawPlayer(playerOne.Position.x, playerOne.Position.y + 1, '|', ConsoleColor.Yellow);
                    DrawPlayer(playerOne.Position.x, playerOne.Position.y, '|', ConsoleColor.Yellow);
                    DrawPlayer(playerOne.Position.x, playerOne.Position.y - 1, '|', ConsoleColor.Yellow);
                    DrawPlayer(playerOne.Position.x, playerOne.Position.y - 2, '|', ConsoleColor.Yellow);

                    DrawPlayer(playerTwo.Position.x, playerTwo.Position.y + 2, '|', ConsoleColor.Blue);                    
                    DrawPlayer(playerTwo.Position.x, playerTwo.Position.y + 1, '|', ConsoleColor.Blue);
                    DrawPlayer(playerTwo.Position.x, playerTwo.Position.y, '|', ConsoleColor.Blue);
                    DrawPlayer(playerTwo.Position.x, playerTwo.Position.y - 1, '|', ConsoleColor.Blue);
                    DrawPlayer(playerTwo.Position.x, playerTwo.Position.y - 2, '|', ConsoleColor.Blue);

                    Ball.Position.y += moveNumY;
                    Ball.Position.x += moveNumX;

                    if (Ball.Position.y == 0)
                    {
                        moveNumY = 1;

                    }
                    else if (Ball.Position.y == Console.WindowHeight - 2)
                    {
                        moveNumY = -1;
                    }

                    if (Ball.Position.y - playerTwo.Position.y <= 2 && Ball.Position.y - playerTwo.Position.y >= -2 && Ball.Position.x >= Console.WindowWidth - 2)
                    {
                        moveNumX = -1;
                    }
                    else if (Ball.Position.x >= Console.WindowWidth - 2)
                    {
                        points1++;
                        break;
                    }
                    if (Ball.Position.y - playerOne.Position.y <= 2 && Ball.Position.y - playerOne.Position.y >= -2 && Ball.Position.x <= 2)
                    {
                        moveNumX = 1;
                    }
                    else if (Ball.Position.x <= 2)
                    {
                        points2++;
                        break;
                    }

                    if (Console.KeyAvailable)
                    {
                        var key = Console.ReadKey(true);

                        if (key.Key == ConsoleKey.W)
                        {

                            playerOne.Position.y -= 1;
                            if (playerOne.Position.y <= 2)
                            {
                                playerOne.Position = new Vector2(1, Console.WindowHeight - 3);
                            }
                        }
                        if (key.Key == ConsoleKey.S)
                        {
                            playerOne.Position.y += 1;
                            if (playerOne.Position.y >= Console.WindowHeight - 2)
                            {
                                playerOne.Position = new Vector2(1, 3);
                            }
                        }
                        if (key.Key == ConsoleKey.UpArrow)
                        {
                            playerTwo.Position.y -= 1;
                            if (playerTwo.Position.y <= 2)
                            {
                                playerTwo.Position = new Vector2(Console.WindowWidth - 2, Console.WindowHeight - 3);
                            }
                        }
                        if (key.Key == ConsoleKey.DownArrow)
                        {
                            playerTwo.Position.y += 1;
                            if (playerTwo.Position.y >= Console.WindowHeight - 2)
                            {
                                playerTwo.Position = new Vector2(Console.WindowWidth - 2, 3);
                            }
                        }
                    }
                    Thread.Sleep(timeScale);

                }

                var title1 = $"Player 1 points: {points1}";
                Console.CursorLeft = Console.BufferWidth / 4 - title1.Length / 2;
                Console.CursorTop = Console.WindowHeight - Console.WindowHeight *3 / 4;
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(title1);

                var title2 = $"Player 2 points: {points2}";
                Console.CursorLeft = Console.BufferWidth *3 / 4 - title1.Length;
                Console.CursorTop = Console.WindowHeight - Console.WindowHeight * 3 / 4;
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(title2);

                if (points2 == 3)
                {
                    var winPlayer2 = $"Player 2 win! Congraduations!";
                    Console.CursorLeft = Console.BufferWidth / 2 - winPlayer2.Length / 2;
                    Console.CursorTop = Console.WindowHeight / 2;
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine(winPlayer2);
                    Console.ReadKey();
                    break;
                }

                if (points1 == 3)
                {
                    var winPlayer1 = $"Player 1 win! Congraduations!";
                    Console.CursorLeft = Console.BufferWidth / 2 - winPlayer1.Length / 2;
                    Console.CursorTop = Console.WindowHeight / 2;
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine(winPlayer1);
                    Console.ReadKey();
                    break;
                }

                if (points2 == 3)
                {
                    var winPlayer2 = $"Player 2 win! Congraduations!";
                    Console.CursorLeft = Console.BufferWidth / 2 - winPlayer2.Length / 2;
                    Console.CursorTop = Console.WindowHeight / 2;
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine(winPlayer2);
                    Console.ReadKey();
                    break;
                }

                Console.ReadKey();
                
            }
        }
    }
}
